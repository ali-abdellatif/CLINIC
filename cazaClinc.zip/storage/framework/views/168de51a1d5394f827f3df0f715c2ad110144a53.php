<?php $__env->startSection('title'); ?>
    cazaClinic/Clinic
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    @toastr_css
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Clinic</span></h4>

        <!-- Basic Bootstrap Table -->
        <div class="card">
            <div class="col-md-3" style="padding: 20px;">
                <a href="<?php echo e(url(route('clinics.create'))); ?>"><button class="btn-info">add Clinic</button></a>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Clinic Name</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>timing From</th>
                        <th>timing To</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                    <?php $i = 0; ?>
                    <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php $i++; ?>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($clinic->name); ?></td>
                            <td><?php echo e($clinic->address); ?></td>
                            <td><?php echo e(App\Models\City::where('id',$clinic->city_id)->first()->name); ?></td>
                            <td><?php echo e($clinic->timing_from); ?> <span>am</span></td>
                            <td><?php echo e($clinic->timing_to); ?> <span>pm</span></td>
                            <td><img width="120" src="<?php echo e(asset('public/' . $clinic->image)); ?>"></td>
                            <td>
                                <button class="btn btn-success" type="button" data-bs-toggle="modal"
                                        data-original-title="test" data-bs-target="#edit<?php echo e($clinic->id); ?>"><i class="fa fa-edit">edit</i>
                                </button>
                                <button class="btn btn-danger" type="button" data-bs-toggle="modal"
                                        data-original-title="test" data-bs-target="#exampleModal<?php echo e($clinic->id); ?>"><i class="fa fa-remove">delete</i>
                                </button>
                            </td>
                        </tr>

                        <!-- edit_modal_Grade -->
                        <div class="modal fade" id="edit<?php echo e($clinic->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel"> City Edit</h5>
                                        <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('clinics.update',$clinic->id)); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo e(method_field('patch')); ?>

                                            <?php echo csrf_field(); ?>
                                            <div>
                                                <div class="row mb-3">
                                                    <div class="col-6">
                                                        <label class="form-label">Clinic Name</label>
                                                        <input class="form-control" name="name" type="text" value="<?php echo e($clinic->name); ?>" />
                                                    </div>
                                                    <div class="col-6">
                                                        <label class="form-label">Address</label>
                                                        <input class="form-control" name="address" type="text" value="<?php echo e($clinic->address); ?>" />
                                                    </div>

                                                </div>
                                                <div class="row mb-3">
                                                    <div class="col-4">
                                                        <label class="form-label">longitude</label>
                                                        <input class="form-control" name="longitude" type="text" value="<?php echo e($clinic->longitude); ?>" />
                                                    </div>
                                                    <div class="col-4">
                                                        <label class="form-label">latitude</label>
                                                        <input class="form-control" name="latitude" type="text" value="<?php echo e($clinic->latitude); ?>" />
                                                    </div>
                                                    <div class="col-4">
                                                        <label class="form-label">Choose City</label>
                                                        <select class="form-control" name="city_id">
                                                            <option selected>Choose...</option>
                                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($city->id); ?>" <?php if($city->id == $clinic->city_id): ?> selected <?php endif; ?>><?php echo e($city->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row mb-3">
                                                    <div class="col-6">
                                                        <label class="form-label">Timing From</label>
                                                        <input class="form-control" name="timing_from" type="time" value="<?php echo e($clinic->timing_from); ?>" />
                                                    </div>
                                                    <div class="col-6">
                                                        <label class="form-label">timing to</label>
                                                        <input class="form-control" name="timing_to" type="time" value="<?php echo e($clinic->timing_to); ?>" />
                                                    </div>

                                                </div>
                                                <div class="mb-3">
                                                    <img width="120" src="<?php echo e(asset('public/' . $clinic->image)); ?>">
                                                    <hr>
                                                    <label for="formFileMultiple" class="form-label">Choose Your Image</label>
                                                    <input class="form-control" name="image" type="file" id="formFileMultiple" multiple />
                                                </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button class="btn btn-primary" type="button" data-bs-dismiss="modal">close</button>
                                                <button class="btn btn-secondary" type="submit">submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <!-- delete_modal_Grade -->
                        <div class="modal fade" id="exampleModal<?php echo e($clinic->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Delete City</h5>
                                        <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <form action="<?php echo e(route('clinics.destroy',$clinic->id)); ?>" method="post">
                                        <?php echo e(method_field('Delete')); ?>

                                        <?php echo csrf_field(); ?>
                                        <input id="id" type="hidden" name="id" class="form-control"
                                               value="<?php echo e($clinic->id); ?>">
                                        <div class="modal-body">Are You Sure To Delete This City</div>
                                        <div class="modal-footer">
                                            <button class="btn btn-primary" type="button" data-bs-dismiss="modal">Close</button>
                                            <button class="btn btn-secondary" type="submit">Submit</button>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!--/ Basic Bootstrap Table -->

    </div>
    <!-- / Content -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    @jquery
    @toastr_js
    @toastr_render
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cazaClinc\resources\views/dashboard/clinics/index.blade.php ENDPATH**/ ?>