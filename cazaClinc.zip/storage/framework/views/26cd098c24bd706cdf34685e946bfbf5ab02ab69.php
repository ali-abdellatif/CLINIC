<?php $__env->startSection('title'); ?>
    cazaClinic/add-SubService
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Add New Sub-Service</span></h4>

        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header">Add Sub-Service</h5>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('subServices.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div>
                                <div class="row mb-3">
                                    <div class="col-6">
                                        <label for="formFileMultiple" class="form-label">Add New Sub-Service</label>
                                        <input class="form-control" name="name" type="text" id="formFileMultiple" />
                                    </div>
                                    <div class="col-6">
                                        <label for="formFileMultiple" class="form-label">Service</label>
                                        <select class="form-control" name="service_id">
                                            <option selected>Choose...</option>
                                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="formFileMultiple" class="form-label">Price</label>
                                        <input class="form-control" name="price" type="number" id="formFileMultiple" />
                                    </div>
                                </div>
                                <div>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- / Content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cazaClinc\resources\views/dashboard/subServices/add.blade.php ENDPATH**/ ?>