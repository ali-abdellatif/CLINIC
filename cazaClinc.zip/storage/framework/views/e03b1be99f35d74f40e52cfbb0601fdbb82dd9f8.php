<?php $__env->startSection('title'); ?>
    cazaClinic/AddCity
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Add New City</span></h4>

        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header">Add City</h5>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('cities.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div>
                                <div class="mb-3">
                                    <label for="formFileMultiple" class="form-label">Add New City</label>
                                    <input class="form-control" name="name" type="text" id="formFileMultiple" />
                                </div>
                                <div>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- / Content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cazaClinc\resources\views/dashboard/cities/add.blade.php ENDPATH**/ ?>